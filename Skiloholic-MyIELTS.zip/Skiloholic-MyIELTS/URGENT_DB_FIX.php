<?php
/**
 * EMERGENCY DATABASE COLUMNS FIX
 * Run this file ONCE to add missing columns
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

echo "<h2>Database Column Fix Script</h2>";
echo "<p>Adding missing columns...</p>";

try {
    // Add email_verified column
    db_execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified BOOLEAN DEFAULT FALSE AFTER password");
    echo "✓ Added email_verified column<br>";
    
    // Copy is_verified to email_verified
    db_execute("UPDATE users SET email_verified = is_verified WHERE is_verified IS NOT NULL");
    echo "✓ Copied is_verified data to email_verified<br>";
    
    // Add password_hash column  
    db_execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255) NULL AFTER password");
    echo "✓ Added password_hash column<br>";
    
    // Copy password to password_hash
    db_execute("UPDATE users SET password_hash = password WHERE password IS NOT NULL AND (password_hash IS NULL OR password_hash = '')");
    echo "✓ Copied password data to password_hash<br>";
    
    echo "<h3>Database structure fixed successfully!</h3>";
    echo "<p><a href='profile/dashboard.php'>Go to Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<h3 style='color: red;'>Error: " . $e->getMessage() . "</h3>";
    echo "<p>If column already exists, this error can be ignored.</p>";
}

// Show current columns
echo "<h3>Current users table structure:</h3>";
try {
    $columns = db_fetch_all("SHOW COLUMNS FROM users");
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>{$col['Field']}</td>";
        echo "<td>{$col['Type']}</td>";
        echo "<td>{$col['Null']}</td>";
        echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "Could not fetch table structure: " . $e->getMessage();
}
?>
