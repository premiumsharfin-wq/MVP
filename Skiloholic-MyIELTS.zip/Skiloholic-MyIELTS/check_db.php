<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

try {
    $stmt = $pdo->query("DESCRIBE evaluations");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "Evaluations Columns: " . implode(', ', $columns) . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
