-- DIAGNOSTIC QUERY - Run this first to see what columns you actually have
SHOW COLUMNS FROM `users`;
