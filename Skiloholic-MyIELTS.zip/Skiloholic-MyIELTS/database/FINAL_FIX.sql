-- FINAL SIMPLE FIX
-- This only adds password_hash if it doesn't exist
-- Run this in phpMyAdmin SQL tab

-- Add password_hash column if it doesn't exist
ALTER TABLE `users` ADD COLUMN `password_hash` VARCHAR(255) NULL;

-- If you already have password_hash column, you'll see an error that you can ignore
-- Otherwise, you'll see "Query executed successfully"

SELECT 'Done! Column added if it was missing.' AS Message;
