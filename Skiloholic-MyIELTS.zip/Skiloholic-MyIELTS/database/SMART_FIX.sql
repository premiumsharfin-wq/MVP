-- SMART FIX - Only adds columns if they don't exist
-- Run this after checking your columns with CHECK_COLUMNS.sql

-- Check and add email_verified if needed
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'email_verified');
    
SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE `users` ADD COLUMN `email_verified` BOOLEAN DEFAULT FALSE;',
    'SELECT "email_verified already exists" AS status;');
    
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and add password_hash if needed  
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'password_hash');
    
SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE `users` ADD COLUMN `password_hash` VARCHAR(255) NULL;',
    'SELECT "password_hash already exists" AS status;');
    
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Copy data if columns exist
UPDATE `users` SET `email_verified` = `is_verified` WHERE `is_verified` IS NOT NULL AND `email_verified` IS NULL;
UPDATE `users` SET `password_hash` = `password` WHERE `password` IS NOT NULL AND (`password_hash` IS NULL OR `password_hash` = '');

SELECT 'Fix complete!' AS Message;
