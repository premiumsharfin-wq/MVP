-- CRITICAL DATABASE FIX
-- Run this in phpMyAdmin SQL tab
-- This fixes column name mismatches between schema and code

-- 1. Add email_verified column (code expects this but schema has is_verified)
ALTER TABLE `users` ADD COLUMN `email_verified` BOOLEAN DEFAULT FALSE AFTER `password`;

-- 2. Copy data from is_verified to email_verified
UPDATE `users` SET `email_verified` = `is_verified` WHERE `is_verified` IS NOT NULL;

-- 3. Add password_hash column (some code expects this)
ALTER TABLE `users` ADD COLUMN `password_hash` VARCHAR(255) NULL AFTER `email_verified`;

-- 4. Copy password to password_hash
UPDATE `users` SET `password_hash` = `password` WHERE `password` IS NOT NULL AND (`password_hash` IS NULL OR `password_hash` = '');

-- Done! You should see a success message
SELECT 'Database columns fixed successfully!' AS Message;
