-- Migration Script for User Profile System Features
-- This script adds new columns to existing tables for the profile system

-- Add new columns to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS avatar_url VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS target_band DECIMAL(2,1) NULL,
ADD COLUMN IF NOT EXISTS exam_date DATE NULL;

-- Add custom test columns to submissions table
ALTER TABLE submissions 
ADD COLUMN IF NOT EXISTS custom_task1_question TEXT NULL,
ADD COLUMN IF NOT EXISTS custom_task1_image VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS custom_task2_question TEXT NULL;

-- Ensure correct column ordering (optional, for consistency)
-- Note: This is safe because it doesn't modify the data, just reorders columns

-- Create uploads directory structure
-- Run this command manually in terminal:
-- mkdir -p uploads/avatars uploads/custom-tests

-- Verify changes
SELECT 'Migration complete! New columns added to users and submissions tables.' AS status;
