<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

try {
    // Check if column exists
    $stmt = $pdo->query("SHOW COLUMNS FROM evaluations LIKE 'assigned_at'");
    $exists = $stmt->fetch();

    if (!$exists) {
        $pdo->exec("ALTER TABLE evaluations ADD COLUMN assigned_at TIMESTAMP NULL AFTER estimated_completion_time");
        echo "Column 'assigned_at' added successfully.<br>";
    } else {
        echo "Column 'assigned_at' already exists.<br>";
    }

    // Check if 'source' column in writing_tests is VARCHAR
    $stmt = $pdo->query("SHOW COLUMNS FROM writing_tests LIKE 'source'");
    $column = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Simple check if type contains enum
    if (strpos($column['Type'], 'enum') !== false) {
        $pdo->exec("ALTER TABLE writing_tests MODIFY COLUMN source VARCHAR(255) NOT NULL DEFAULT 'Other'");
        echo "Column 'source' modified to VARCHAR(255).<br>";
    } else {
        echo "Column 'source' is already compliant (" . $column['Type'] . ").<br>";
    }

} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
}
?>
